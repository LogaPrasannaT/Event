import java.sql.Connection;
import java.time.LocalDateTime;
import java.sql.Timestamp;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;

class Main
{
private static Connection connection = null;

public static void main(String s[])
{
try
{
Class.forName("com.mysql.jdbc.Driver");
connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Event_Management", "root", "");
System.out.println("Database Connected Successfully");
}
catch(ClassNotFoundException | SQLException e)
{
e.printStackTrace();
}
PreparedStatement statement = null;

try
{
String query = "insert into Feedback(Feedback_id,Event_id,Attendee_id,Feedback_rating,Feedback_comment,Feedback_date) values (?,?,?,?,?,?)";
statement = connection.prepareStatement(query);

statement.setInt(1,1);
statement.setInt(2,4);
statement.setInt(3,1);
statement.setInt(4,5);
statement.setString(5,"Wonderful Place to celebrate birthday party function");
statement.setTimestamp(6,Timestamp.valueOf(LocalDateTime.now()));
int row = statement.executeUpdate();

if(row > 0)
{
System.out.println("Feedback Given Data's Added Succesfully");
}
}
catch(SQLException e)
{
System.out.println(e);
}

}
}

