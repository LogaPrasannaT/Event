import java.time.LocalDate;
import java.sql.Timestamp;
public class Sponsers
{
private int id;
private String name;
private String email;
private long phone;

private Sponsers()
{
}

Sponsers(int id, String name,String email,long phone)
{
this.id = id;
this.name = name;
this.email = email;
this.phone = phone;
}

public int getId()
{
return id;
}

public String getName()
{
return name;
}

public String getEmail()
{
return email;
}

public long getPhone()
{
return phone;
}
}
