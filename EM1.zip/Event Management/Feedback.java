import java.time.LocalDate;
import java.sql.Timestamp;
public class Feedback
{
private int id;
private String rating;
private String comment;
private LocalDate date ;

private Feedback()
{
}

Feedback(int id, String rating, String comment,LocalDate date)
{
this.id = id;
this.rating = rating;
this.comment = comment;
this.date = date;
}

public int getId()
{
return id;
}

public String getRating()
{
return rating;
}

public String getComment()
{
return comment;
}

public LocalDate getDate()
{
return date;
}
}
