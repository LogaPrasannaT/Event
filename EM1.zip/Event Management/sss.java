public class MySQLqueries
{
public static final String createAdmin_Table =
"CREATE TABLE IF NOT EXISTS Admin ("+
    "Admin_Id INT(11) NOT NULL AUTO_INCREMENT,"+
    "Admin_UserName VARCHAR(20) NOT NULL UNIQUE,"+
    "Password VARCHAR(20) DEFAULT NULL,"+
    "Name VARCHAR(20) DEFAULT NULL,"+
    "Company VARCHAR(20) NOT NULL,"+
    "PRIMARY KEY (Admin_Id))";
   
public static final String createEvents_Table = 
"CREATE TABLE IF NOT EXISTS Events ("+ 
 "Event_id int(11) primary key auto_increment,Event_name varchar(50),Event_date timestamp not null default current_timestamp,Event_location varchar(50),Event_description text,Event_capacity int );
   
   
   create table Speakers(
    -> Speaker_id int not null,
    -> Speaker_name varchar(50),
    -> Speaker_bio text,
    -> Speaker_email varchar(50),
    -> Speaker_phone bigint,
    -> foreign key(Event_id) references Events(Event_id));


   create table Attendees(
    -> Attendee_id int not null,
    -> Event id int not null,
    -> Attendee_name varchar(50),
    -> Attendee_email varchar(50),
    -> Attendee_phone bigint,
    -> Registration_date date,
    -> foreign key(Event_id) references Events(Event_id));


create table Sponsers(
    -> Sponser_id int not null,
    -> Sponser_name varchar(50) not null,
    -> Sponser_email varchar(50) not null,
    -> Sponser_phone bigint not null,
    -> Event_id int not null,
    -> foreign key(Event_id) references Events(Event_id));


create table Tasks(
    -> Task_id int not null,
    -> Task_name varchar(50) not null,
    -> Task_description text not null,
    -> Task_due_date timestamp not null default current_timestamp,
    -> Task_status varchar(50) not null,
    -> Event_id int not null,
    -> foreign key(Event_id) references Events(Event_id));


create table Feedback(
    -> Feedback_id int not null,
    -> Event_id int not null,
    -> Attendee_id int not null,
    -> Feedback_rating int not null,
    -> Feedback_comment text not null,
    -> Feedback_date timestamp not null default current_timestamp,
    -> foreign key(Event_id) references Events(Event_id),
    -> foreign key(Attendee_id) references Attendees(Attendee_id));




String query = "insert into Events(Event_name,Event_date,Event_location,Event_description,Event_capacity) values (?,?,?,?,?)";
String query = "insert into Tasks(Task_id,Task_name,Task_description,Task_due_date,Task_status,Event_id) values (?,?,?,?,?,?)";
String query = "insert into Attendees(Attendee_id,Event_id,Attendee_name,Attendee_email,Attendee_phone,Registration_date) values (?,?,?,?,?,?)";
String query = "insert into Speakers(Speaker_id,Speaker_name,Speaker_bio,Speaker_email,Event_id,Speaker_phone) values (?,?,?,?,?,?)";
String query = "insert into Feedback(Feedback_id,Event_id,Attendee_id,Feedback_rating,Feedback_comment,Feedback_date) values (?,?,?,?,?,?)";
String query = "insert into Feedback(Sponser_id,Sponser_name,Sponser_email,Sponser_phone,Event_id,) values (?,?,?,?,?)";
