import java.time.LocalDate;
import java.sql.Timestamp;
public class Events
{
private String name;
private LocalDate date;
priavte String Location;
private String description;
private int capacity;

private Events{}

Events(String name, LocalDate date,String Location,String description, int capacity)
{
this.name = name;
this.date = date
this.location=location;
this.description = description;
this.capacity=capacity;
}


public String getName()
{
return name;
}

public LocalDate getDate()
{
return date;
}

public String getDescription()
{
return description;
}

public String getLocation()
{
return location;
}

public String getCapacity()
{
return capacity;
}
}
