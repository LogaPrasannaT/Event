import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Scanner;

public class EventManagement
{
  private static Connection connection = null;
  private static EventManagement instance = null;
  private static final Scanner sc = new Scanner (System.in);

  private EventManagement ()
  {
  }

  public static EventManagement getInstance ()
  {
	if (instance == null)
	  {
		instance = new EventManagement ();
	  }
	return instance;
  }

  public static void main (String[]args)
  {
	try
	{
	  Class.forName ("com.mysql.jdbc.Driver");
	  connection =DriverManager.getConnection ("jdbc:mysql://localhost:3306/Event_Management", "root",   "");
	  System.out.println ("Database Connected Successfully");

	  EventManagement eventManagement = EventManagement.getInstance ();
	  eventManagement.createTables ();
	  eventManagement.menu ();
	} catch (ClassNotFoundException | SQLException e)
	{
	  e.printStackTrace ();
	}
  }

  private void createTables ()
  {
	executeUpdate (SQLQueries.createEvents_Table);
	executeUpdate (SQLQueries.createSpeakers_Table);
	executeUpdate (SQLQueries.createAttendees_Table);
	executeUpdate (SQLQueries.createSponsers_Table);
	executeUpdate (SQLQueries.createTasks_Table);
	executeUpdate (SQLQueries.createFeedback_Table);
  }

  private void executeUpdate (String query)
  {
	try (PreparedStatement statement = connection.prepareStatement (query))
	{
	  statement.execute ();
	} catch (SQLException e)
	{
	  e.printStackTrace ();
	}
  }

  public void menu ()
  {
	while (true)
	  {
		System.out.println("Enter the choice: \n 1. Add Event \n 2. Add Speaker \n 3. Add Attendee \n 4. Add Sponser \n 5. Add Task \n 6. Add Feedback \n 7. Exit");
		int choice = sc.nextInt ();

		switch (choice)
		  {
		  case 1:
			      addEvent ();
			      break;
		                       case 2:
			                           addSpeaker ();
			                           break;
		                                            case 3:
			                                                addAttendee ();
			                                                break;
		  									  case 4:
												      addSponser ();
												      break;
		  										                case 5:
			                                                                                          addTask ();
			                                                                                          break;
		                                                                                                           case 6:
			                                                                                                               addFeedback ();
			                                                                                                               break;
		                                                                                                                                case 7:
			                                                                                                                                    System.exit (0);
			                                                                                                                                    break;
		                                                                                                                                                     default:
																								        System.out.println ("Invalid choice, please try again.");
		  }
	  }
  }

  private void addEvent ()
  {
	try
	{
	  PreparedStatement statement =
		connection.prepareStatement (SQLQueries.insert_Event);
	  statement.setString (1, "LOKI");
	  statement.setTimestamp (2, Timestamp.valueOf (LocalDateTime.now ()));
	  statement.setString (3, "Madurai");
	  statement.setString (4, "Bday Party");
	  statement.setInt (5, 10);

	  int row = statement.executeUpdate ();
	  if (row > 0)
		{
		  System.out.println ("Event added successfully");
		}
	}
	catch (SQLException e)
	{
	  e.printStackTrace ();
	}
  }

  private void addSpeaker ()
  {
	try
	{
	  PreparedStatement statement =
		connection.prepareStatement (SQLQueries.insert_Speaker);
	  statement.setInt (1, 1);
	  statement.setString (2, "John Doe");
	  statement.setString (3, "Speaker Bio");
	  statement.setString (4, "johndoe@example.com");
	  statement.setLong (5, 1234567890L);
	  statement.setInt (6, 1);

	  int row = statement.executeUpdate ();
	  if (row > 0)
		{
		  System.out.println ("Speaker added successfully");
		}
	}
	catch (SQLException e)
	{
	  e.printStackTrace ();
	}
  }

  private void addAttendee ()
  {
	try
	{
	  PreparedStatement statement =
		connection.prepareStatement (SQLQueries.insert_Attendee);
	  statement.setInt (1, 1);
	  statement.setInt (2, 1);
	  statement.setString (3, "Prasanna");
	  statement.setString (4, "prasanna@example.com");
	  statement.setLong (5, 9486731906L);
	  statement.setTimestamp (6, Timestamp.valueOf (LocalDateTime.now ()));

	  int row = statement.executeUpdate ();
	  if (row > 0)
		{
		  System.out.println ("Attendee added successfully");
		}
	}
	catch (SQLException e)
	{
	  e.printStackTrace ();
	}
  }

  private void addSponser ()
  {
	try
	{
	  PreparedStatement statement =
		connection.prepareStatement (SQLQueries.insert_Sponser);
	  statement.setInt (1, 1);
	  statement.setString (2, "ABC Corp");
	  statement.setString (3, "contact@abccorp.com");
	  statement.setLong (4, 9876543210L);
	  statement.setInt (5, 1);

	  int row = statement.executeUpdate ();
	  if (row > 0)
		{
		  System.out.println ("Sponser added successfully");
		}
	}
	catch (SQLException e)
	{
	  e.printStackTrace ();
	}
  }

  private void addTask ()
  {
	try
	{
	  PreparedStatement statement =
		connection.prepareStatement (SQLQueries.insert_Task);
	  statement.setInt (1, 1);
	  statement.setString (2, "Setup Venue");
	  statement.setString (3, "Setup the venue for the event");
	  statement.setTimestamp (4,  Timestamp.valueOf (LocalDateTime.now().	plusDays (5)));
	  statement.setString (5, "Pending");
	  statement.setInt (6, 1);

	  int row = statement.executeUpdate ();
	  if (row > 0)
		{
		  System.out.println ("Task added successfully");
		}
	}
	catch (SQLException e)
	{
	  e.printStackTrace ();
	}
  }

  private void addFeedback ()
  {
	try
	{
	  PreparedStatement statement =
		connection.prepareStatement (SQLQueries.insert_Feedback);
	  statement.setInt (1, 1);
	  statement.setInt (2, 1);
	  statement.setInt (3, 1);
	  statement.setInt (4, 5);
	  statement.setString (5, "Great event!");
	  statement.setTimestamp (6, Timestamp.valueOf (LocalDateTime.now ()));

	  int row = statement.executeUpdate ();
	  if (row > 0)
		{
		  System.out.println ("Feedback added successfully");
		}
	}
	catch (SQLException e)
	{
	  e.printStackTrace ();
	}
  }
}

