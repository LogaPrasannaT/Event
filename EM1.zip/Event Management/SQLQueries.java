public class SQLQueries {
    public static final String createUsersTable = 
        "CREATE TABLE IF NOT EXISTS Users (" +
        "User_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT," +
        "User_name VARCHAR(50) NOT NULL," +
        "User_email VARCHAR(50) NOT NULL UNIQUE," +
        "User_password VARCHAR(50) NOT NULL," +
        "Is_admin BOOLEAN NOT NULL DEFAULT FALSE)";

    public static final String createEventsTable = 
        "CREATE TABLE IF NOT EXISTS Events (" +
        "Event_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT," +
        "Event_name VARCHAR(50) NOT NULL," +
        "Event_date TIMESTAMP NOT NULL," +
        "Event_location VARCHAR(50) NOT NULL," +
        "Event_description TEXT," +
        "Event_capacity INT NOT NULL)";

    public static final String createSpeakersTable = 
        "CREATE TABLE IF NOT EXISTS Speakers (" +
        "Speaker_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT," +
        "Speaker_name VARCHAR(50) NOT NULL," +
        "Speaker_bio TEXT," +
        "Speaker_email VARCHAR(50) NOT NULL," +
        "Speaker_phone BIGINT NOT NULL," +
        "Event_id INT NOT NULL," +
        "FOREIGN KEY (Event_id) REFERENCES Events(Event_id))";

    public static final String createAttendeesTable = 
        "CREATE TABLE IF NOT EXISTS Attendees (" +
        "Attendee_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT," +
        "Event_id INT NOT NULL," +
        "Attendee_name VARCHAR(50) NOT NULL," +
        "Attendee_email VARCHAR(50) NOT NULL," +
        "Attendee_phone BIGINT NOT NULL," +
        "Registration_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP," +
        "FOREIGN KEY (Event_id) REFERENCES Events(Event_id))";

    public static final String createSponsorsTable = 
        "CREATE TABLE IF NOT EXISTS Sponsors (" +
        "Sponsor_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT," +
        "Sponsor_name VARCHAR(50) NOT NULL," +
        "Sponsor_email VARCHAR(50) NOT NULL," +
        "Sponsor_phone BIGINT NOT NULL," +
        "Event_id INT NOT NULL," +
        "FOREIGN KEY (Event_id) REFERENCES Events(Event_id))";

    public static final String createTasksTable = 
        "CREATE TABLE IF NOT EXISTS Tasks (" +
        "Task_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT," +
        "Registered_By VARCHAR(50) NOT NULL," +
        "Task_description TEXT NOT NULL," +
        "Task_status VARCHAR(50) NOT NULL," +
        "Event_id INT NOT NULL," +
        "FOREIGN KEY (Event_id) REFERENCES Events(Event_id))";

    public static final String createFeedbackTable = 
        "CREATE TABLE IF NOT EXISTS Feedback (" +
        "Feedback_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT," +
        "Event_id INT NOT NULL," +
        "Attendee_id INT NOT NULL," +
        "Feedback_rating INT NOT NULL," +
        "Feedback_comment TEXT," +
        "Feedback_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP," +
        "FOREIGN KEY (Event_id) REFERENCES Events(Event_id)," +
        "FOREIGN KEY (Attendee_id) REFERENCES Attendees(Attendee_id))";

    public static final String createRolesTable = 
        "CREATE TABLE IF NOT EXISTS Roles (" +
        "Role_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT," +
        "Role_name VARCHAR(50) NOT NULL)";

    public static final String createUserEventsTable = 
        "CREATE TABLE IF NOT EXISTS UserEvents (" +
        "UserEvent_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT," +
        "User_id INT NOT NULL," +
        "Event_id INT NOT NULL," +
        "FOREIGN KEY (User_id) REFERENCES Users(User_id)," +
        "FOREIGN KEY (Event_id) REFERENCES Events(Event_id))";

    public static final String insertUser = 
        "INSERT INTO Users (User_name, User_email, User_password, Is_admin) VALUES (?, ?, ?, ?)";

    public static final String insertEvent = 
        "INSERT INTO Events (Event_name, Event_date, Event_location, Event_description, Event_capacity) VALUES (?, ?, ?, ?, ?)";

    public static final String insertSpeaker = 
        "INSERT INTO Speakers (Speaker_name, Speaker_bio, Speaker_email, Speaker_phone, Event_id) VALUES (?, ?, ?, ?, ?)";

    public static final String insertAttendee = 
        "INSERT INTO Attendees (Event_id, Attendee_name, Attendee_email, Attendee_phone) VALUES (?, ?, ?, ?)";

    public static final String insertSponsor = 
        "INSERT INTO Sponsors (Sponsor_name, Sponsor_email, Sponsor_phone, Event_id) VALUES (?, ?, ?, ?)";

    public static final String insertTask = 
        "INSERT INTO Tasks (Registered_By, Task_description, Task_status, Event_id) VALUES (?, ?, ?, ?)";

    public static final String insertFeedback = 
        "INSERT INTO Feedback (Event_id, Attendee_id, Feedback_rating, Feedback_comment) VALUES (?, ?, ?, ?)";

    public static final String insertRole = 
        "INSERT INTO Roles (Role_name) VALUES (?)";

    public static final String insertUserEvent = 
        "INSERT INTO UserEvents (User_id, Event_id) VALUES (?, ?)";

    public static final String getAllEvents = 
        "SELECT * FROM Events";

    public static final String getEventDetails = 
        "SELECT * FROM Events WHERE Event_id = ?";

    public static final String getUserByEmail = 
        "SELECT * FROM Users WHERE User_email = ?";

    public static final String getTasksByEvent = 
        "SELECT * FROM Tasks WHERE Event_id = ?";

    public static final String getSpeakersByEvent = 
        "SELECT * FROM Speakers WHERE Event_id = ?";
}

