import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class EventManagement {
    private static Connection connection = null;
    private static EventManagement instance = null;
    private static final Scanner sc = new Scanner(System.in);

    private EventManagement() {}

    public static EventManagement getInstance() {
        if (instance == null) {
            instance = new EventManagement();
        }
        return instance;
    }

    public static void main(String[] args) {
        try {
            // Database connection
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Event_Management", "root", "");
            System.out.println("Database Connected Successfully");

            // Initialize EventManagement instance and create tables
            EventManagement eventManagement = EventManagement.getInstance();
            eventManagement.createTables();

            // Start the menu
            eventManagement.menu();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to create necessary tables
    private void createTables() {
        executeUpdate(SQLQueries.createUsersTable);
        executeUpdate(SQLQueries.createEventsTable);
        executeUpdate(SQLQueries.createSpeakersTable);
        executeUpdate(SQLQueries.createAttendeesTable);
        executeUpdate(SQLQueries.createSponsorsTable);
        executeUpdate(SQLQueries.createTasksTable);
        executeUpdate(SQLQueries.createFeedbackTable);
        executeUpdate(SQLQueries.createRolesTable);
        executeUpdate(SQLQueries.createUserEventsTable);
    }

    // Method to execute an update query
    private void executeUpdate(String query) {
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Main menu method
    public void menu() {
        while (true) {
            System.out.println("\nEnter your choice:");
            System.out.println("1. Add User");
            System.out.println("2. Add Event");
            System.out.println("3. Add Speaker");
            System.out.println("4. Add Attendee");
            System.out.println("5. Add Sponsor");
            System.out.println("6. Add Task");
            System.out.println("7. Add Feedback");
            System.out.println("8. View Events");
            System.out.println("9. View Event Details");
            System.out.println("10. Exit");

            int choice = sc.nextInt();
            sc.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addUser();
                    break;
                case 2:
                    addEvent();
                    break;
                case 3:
                    addSpeaker();
                    break;
                case 4:
                    addAttendee();
                    break;
                case 5:
                    addSponsor();
                    break;
                case 6:
                    addTask();
                    break;
                case 7:
                    addFeedback();
                    break;
                case 8:
                    viewEvents();
                    break;
                case 9:
                    viewEventDetails();
                    break;
                case 10:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }

    // Method to add a user to the database
    private void addUser() {
        try {
            PreparedStatement statement = connection.prepareStatement(SQLQueries.insertUser);
            System.out.println("Enter User Name:");
            statement.setString(1, sc.nextLine());
            System.out.println("Enter User Email:");
            statement.setString(2, sc.nextLine());
            System.out.println("Enter User Password:");
            statement.setString(3, sc.nextLine());
            System.out.println("Is Admin (true/false):");
            statement.setBoolean(4, sc.nextBoolean());

            int row = statement.executeUpdate();
            if (row > 0) {
                System.out.println("User added successfully");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to add an event to the database
    private void addEvent() {
        try {
            PreparedStatement statement = connection.prepareStatement(SQLQueries.insertEvent);
            System.out.println("Enter Event Name:");
            statement.setString(1, sc.nextLine());
            System.out.println("Enter Event Date (yyyy-MM-dd HH:mm:ss):");
            String dateString = sc.nextLine();
            LocalDateTime dateTime = LocalDateTime.parse(dateString, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            statement.setTimestamp(2, Timestamp.valueOf(dateTime));
            System.out.println("Enter Event Location:");
            statement.setString(3, sc.nextLine());
            System.out.println("Enter Event Description:");
            statement.setString(4, sc.nextLine());
            System.out.println("Enter Event Capacity:");
            statement.setInt(5, sc.nextInt());

            int row = statement.executeUpdate();
            if (row > 0) {
                System.out.println("Event added successfully");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to add a speaker to the database
    private void addSpeaker() {
        try {
            PreparedStatement statement = connection.prepareStatement(SQLQueries.insertSpeaker);
            System.out.println("Enter Speaker Name:");
            statement.setString(1, sc.nextLine());
            System.out.println("Enter Speaker Bio:");
            statement.setString(2, sc.nextLine());
            System.out.println("Enter Speaker Email:");
            statement.setString(3, sc.nextLine());
            System.out.println("Enter Speaker Phone:");
            statement.setLong(4, sc.nextLong());
            System.out.println("Enter Event ID:");
            statement.setInt(5, sc.nextInt());

            int row = statement.executeUpdate();
            if (row > 0) {
                System.out.println("Speaker added successfully");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to add an attendee to the database
    private void addAttendee() {
        try {
            PreparedStatement statement = connection.prepareStatement(SQLQueries.insertAttendee);
            System.out.println("Enter Event ID:");
            statement.setInt(1, sc.nextInt());
            System.out.println("Enter Attendee Name:");
            statement.setString(2, sc.nextLine());
            System.out.println("Enter Attendee Email:");
            statement.setString(3, sc.nextLine());
            System.out.println("Enter Attendee Phone:");
            statement.setLong(4, sc.nextLong());

            int row = statement.executeUpdate();
            if (row > 0) {
                System.out.println("Attendee added successfully");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to add a sponsor to the database
    private void addSponsor() {
        try {
            PreparedStatement statement = connection.prepareStatement(SQLQueries.insertSponsor);
            System.out.println("Enter Sponsor Name:");
            statement.setString(1, sc.nextLine());
            System.out.println("Enter Sponsor Email:");
            statement.setString(2, sc.nextLine());
            System.out.println("Enter Sponsor Phone:");
            statement.setLong(3, sc.nextLong());
            System.out.println("Enter Event ID:");
            statement.setInt(4, sc.nextInt());

            int row = statement.executeUpdate();
            if (row > 0) {
                System.out.println("Sponsor added successfully");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to add a task to the database
    private void addTask() {
        try {
            PreparedStatement statement = connection.prepareStatement(SQLQueries.insertTask);
            System.out.println("Enter Task Description:");
            statement.setString(1, sc.nextLine());
            System.out.println("Enter Task Status:");
            statement.setString(2, sc.nextLine());
            System.out.println("Enter Event ID:");
            statement.setInt(3, sc.nextInt());

            int row = statement.executeUpdate();
            if (row > 0) {
                System.out.println("Task added successfully");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to add feedback to the database
    private void addFeedback() {
        try {
            PreparedStatement statement = connection.prepareStatement(SQLQueries.insertFeedback);
            System.out.println("Enter Event ID:");
            statement.setInt(1, sc.nextInt());
            System.out.println("Enter Attendee ID:");
            statement.setInt(2, sc.nextInt());
            System.out.println("Enter Feedback Rating:");
            statement.setInt(3, sc.nextInt());
            System.out.println("Enter Feedback Comment:");
            statement.setString(4, sc.nextLine());

            int row = statement.executeUpdate();
            if (row > 0) {
                System.out.println("Feedback added successfully");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to view all events
    private void viewEvents() {
        try {
            PreparedStatement statement = connection.prepareStatement(SQLQueries.getAllEvents);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                System.out.println("Event ID: " + resultSet.getInt("Event_id"));
                System.out.println("Event Name: " + resultSet.getString("Event_name"));
                System.out.println("Event Date: " + resultSet.getTimestamp("Event_date"));
                System.out.println("Event Location: " + resultSet.getString("Event_location"));
                System.out.println("Event Description: " + resultSet.getString("Event_description"));
                System.out.println("Event Capacity: " + resultSet.getInt("Event_capacity"));
                System.out.println("=========================================");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to view details of a specific event
    
    private void viewEventDetails() {
        System.out.println("Enter Event ID to view details:");
        int eventId = sc.nextInt();

        try {
            PreparedStatement eventStatement = connection.prepareStatement(SQLQueries.getEventDetails);
            eventStatement.setInt(1, eventId);
            ResultSet eventResult = eventStatement.executeQuery();

            if (eventResult.next()) {
                System.out.println("Event ID: " + eventResult.getInt("Event_id"));
                System.out.println("Event Name: " + eventResult.getString("Event_name"));
                System.out.println("Event Date: " + eventResult.getTimestamp("Event_date"));
                System.out.println("Event Location: " + eventResult.getString("Event_location"));
                System.out.println("Event Description: " + eventResult.getString("Event_description"));
                System.out.println("Event Capacity: " + eventResult.getInt("Event_capacity"));

                // View Speakers for this event
                PreparedStatement speakerStatement = connection.prepareStatement("SELECT * FROM Speakers WHERE Event_id = ?");
                speakerStatement.setInt(1, eventId);
                ResultSet speakerResult = speakerStatement.executeQuery();

                System.out.println("Speakers:");
                while (speakerResult.next()) {
                    System.out.println(" - " + speakerResult.getString("Speaker_name"));
                }

                // View Attendees for this event
                PreparedStatement attendeeStatement = connection.prepareStatement("SELECT * FROM Attendees WHERE Event_id = ?");
                attendeeStatement.setInt(1, eventId);
                ResultSet attendeeResult = attendeeStatement.executeQuery();

                System.out.println("Attendees:");
                while (attendeeResult.next()) {
                    System.out.println(" - " + attendeeResult.getString("Attendee_name"));
                }

                // View Sponsors for this event
                PreparedStatement sponsorStatement = connection.prepareStatement("SELECT * FROM Sponsors WHERE Event_id = ?");
                sponsorStatement.setInt(1, eventId);
                ResultSet sponsorResult = sponsorStatement.executeQuery();

                System.out.println("Sponsors:");
                while (sponsorResult.next()) {
                    System.out.println(" - " + sponsorResult.getString("Sponsor_name"));
                }

                // View Tasks for this event
                PreparedStatement taskStatement = connection.prepareStatement("SELECT * FROM Tasks WHERE Event_id = ?");
                taskStatement.setInt(1, eventId);
                ResultSet taskResult = taskStatement.executeQuery();

                System.out.println("Tasks:");
                while (taskResult.next()) {
                    System.out.println(" - " + taskResult.getString("Task_name") + " (Due: " + taskResult.getTimestamp("Task_due_date") + ")");
                }
            } else {
                System.out.println("Event not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

