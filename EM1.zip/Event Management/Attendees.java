import java.time.LocalDate;
import java.sql.Timestamp;
public class Attendees
{
private int id;
private String name;
private String email;
private long phone;
private LocalDate date;

private Attendees()
{
}

Attendees(int id, String name, String email,long phone, LocalDate date)
{
this.id = id;
this.name = name;
this.email = email;
this.phone = phone;
this.date = date;
}

public int getId()
{
return id;
}

public String getName()
{
return name;
}

public String getEmail()
{
return email;
}

public long getPhone()
{
return phone;
}

public LocalDate getDate()
{
return date;
}
}
